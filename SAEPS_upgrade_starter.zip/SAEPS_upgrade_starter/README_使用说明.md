# SAEPS 新版研究：矩阵先导实验启动包

## 这个包是什么

这是一个**开发期矩阵试验**，不是完整的新 PINN 算法、不是原论文复现实验，也不是新增论文结果。脚本按公开仓库 `outputs/posthoc/exact_fixed_state_v3` 的 JSON 字段编写；没有修改你的仓库或历史记录。

已在合成正定矩阵上检查配方恒等式、共同嵌套子空间的单调性、仿射残差退化情况、非正定状态块拒绝，以及原始无效记录保留。**没有在本环境执行你的实际 21 个 PINN 检查点。**

特别注意：你仓库的 `src/saeps/v35/second_order.py` 已有 `first_order_reduced_correction`。本包不将这一修正公式宣称为新发现；它测试的是把该修正作为初值，再用共同状态子空间逐步修正响应的可行性。

## 1. 运行

依赖：Python 3.10+、NumPy。建议在已有 SAEPS 环境运行，不必为这个矩阵试验重新训练。

```bash
python pilot_curvature_correction.py --self-test

python pilot_curvature_correction.py \
  --repo /path/to/SAEPS \
  --output /path/to/new_results/curvature_pilot_diag_01 \
  --steps 0,1,3,5,10 \
  --preconditioner gn-diagonal
```

`--output` 必须是**尚不存在的新目录**。脚本拒绝覆盖历史输出，也拒绝写入被冻结的输入归档。

再执行一个乐观控制组，判断“效果瓶颈”与“预处理瓶颈”是否不同：

```bash
python pilot_curvature_correction.py \
  --repo /path/to/SAEPS \
  --output /path/to/new_results/curvature_pilot_exact_preconditioner_01 \
  --steps 0,1,3,5,10 \
  --preconditioner gn-exact
```

这里 `gn-exact` 使用稠密 GN 状态求解，**只是小矩阵开发控制组，不是可扩展性证据**。

## 2. 数学定义

固定同一检查点、残差权重和阻尼。设

\[
A=H_{\theta\theta}+\gamma I,\quad C=H_{\theta\lambda},\quad
Z_0=(G_{\theta\theta}+\gamma I)^{-1}G_{\theta\lambda}.
\]

定义响应近似对应的曲率

\[
K(Z)=H_{\lambda\lambda}-C^TZ-Z^TC+Z^TAZ.
\]

在 `A` 正定时，精确 Schur 曲率为

\[
H_*=H_{\lambda\lambda}-C^TA^{-1}C,
\]

配方给出

\[
K(Z)-H_*=(C-AZ)^TA^{-1}(C-AZ)\succeq0.
\]

`K(Z0)-F_GN` 对应仓库中已有的一阶残余 Hessian 修正。它不保证比原 SAEPS 更准确，也不保证小于 frozen-state GN；应保留所有变差的样本。

脚本从 `D0=C-AZ0` 出发，用预处理响应缺陷扩展**共同的、嵌套的**状态子空间 `V`，求解小型投影系统

\[
Y=(V^TAV)^{-1}V^TD_0,\qquad Z=Z_0+VY.
\]

精确算术下，该变分修正随子空间扩展使 `K` 向精确 Schur 曲率单调下降。脚本同时报告浮点下的正向增量和恒等式残差，不能把小矩阵中的结果直接外推到大网络。

这些线性代数恒等式和 Galerkin 原理不是“新发明”。潜在研究贡献应来自面向物理参数的自适应方向选择、矩阵自由实现、误差停止准则和独立物理验证。

## 3. 输出

- `records.json`：每个原始记录的成功、失败或跳过原因；无效记录不会消失。
- `metrics.csv`：每个子空间预算的原始 GN 误差、修正误差、子空间维度、响应缺陷、恒等式核查等。
- `summary.json`：按问题和预算汇总，并保留计划数与失败数。
- `manifest.json`：输入及脚本 SHA-256、运行版本和开发配置。

主要看：

1. `step_budget=0`：已有二阶投影修正究竟带来多少改善？
2. `step_budget=1,3,5`：少量共同子空间扩展是否有效？
3. `gn-diagonal` 与 `gn-exact`：差距是否表明下一步必须改预处理？
4. 是否存在大幅变差、负的参数约化曲率、谱条件数问题？
5. `gn_vs_archived_saeps_relative_difference`：稠密 GN 与归档 LSQR 基线是否对得上？

## 4. 不可混淆的量

- `dense_oracle_gap_spectral_norm` 使用稠密精确 `A` 解来核验误差；这是**开发验证 oracle**，不能在未来算法的计时或“无需精确参考的停止规则”中偷偷使用。
- `floating_point_mu_bound` 使用浮点特征值计算，不是严格区间算术认证，也不是大网络中免费可得的界。
- `p>1` 时，脚本报告未白化的 Frobenius 误差，不等于原文公式 (37)。当前历史主归档是标量；多参数新版要采用统一的物理坐标尺度或复现原白化定义。
- 检查点不满足驻点条件时，分块 Schur 代数仍可计算，但不能自动称为真实非线性 profile 的 Hessian。
- 历史 21 个有效检查点只能用来开发新方法；新论文的确认性评价需要重新冻结配置、使用新的种子/观测实现。

## 5. 建议的下一阶段模块

保持原代码与输出不变，在新分支或 `src/saeps/v6` 中增加：

| 模块 | 任务 |
|---|---|
| `operators.py` | 统一残差 JVP/VJP 与联合目标 HVP；固定目标、阻尼和坐标 |
| `response_correction.py` | 从 GN 响应出发的共同子空间二阶校正 |
| `preconditioners.py` | 由少量随机 VJP 估计对角预处理；避免 `torch.eye(n_theta)` |
| `profile_continuation.py` | 中心精修、预测-校正 continuation、独立多初值 profile 核验 |
| `state_metric.py` | 可选：独立物理积分网格上的函数空间度量；显式处理半正定/零空间 |
| `benchmarks/darcy2d.py` | 从 p=4 的二维变系数问题开始，不先做大而全模型 |
| `design.py` | 可选：观测追加/设计的闭环应用，不把曲率误差当作后验覆盖率 |

第一阶段继续使用原 `gamma I` 目标，避免同时改变“求解器”和“被测曲率”。函数空间度量属于下一步独立消融。

## 6. 开发与停走规则

**先做这个便宜的矩阵试验，再决定重训练量。** 若投影修正和少量子空间迭代都无优势，应如实保留结果，调整路线，而不是先启动海量二维训练。

进入大网络前，至少满足：原基线可复核；共同子空间恒等式通过；负曲率有明确处理；小规模独立 profile 有收敛窗口；同一阻尼下的完整成本已记录。

本包不保证效果、创新性或期刊录用。最终贡献需要与 variable projection、自然梯度 PINN、经典 Galerkin/CG 误差估计等工作逐项比较。
